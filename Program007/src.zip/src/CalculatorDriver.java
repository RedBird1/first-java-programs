/**
 * 
 */

/**
 * @author Zach
 * 
 *         This sis the test class for the calculator window. Uses of the
 *         CalculatorWindow class create the window.
 *
 */
public class CalculatorDriver {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CalculatorWindow calcApp = new CalculatorWindow();

	}

}
