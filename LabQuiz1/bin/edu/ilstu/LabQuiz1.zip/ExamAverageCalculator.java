/* 
 *File name: ExamAverageCalculator.java
 *
 *Programmer: Zachary Schleder
 *ULID: zschled
 *
 *Date: Sep 24, 2014
 *
 *Class: IT 168
 *Lecture session: SEC-10
 *Lecture Instructor: Matsuda
 *Lab Section: SEC-12
 *Lab Instructor: Nasiba Al-Rawi
 */
package edu.ilstu;

/**
 *<insert clas description here>
 *
 * @author Zachary Schleder
 *
 */
public class ExamAverageCalculator
{
	private double examOne;
	private double examTwo;
	private double examThree;
	
	public ExamAverageCalculator()
	{
		
	}
	
	
	public void ExamAverageCalculator(double exam1, double exam2, double exam3)
	{
		exam1=examOne;
		exam2=examTwo;
		exam3=examThree;
		
	}
	
	public double calculateExamAverage()
	{
		return (examOne*examTwo*examThree)/3;
		
	}

}
