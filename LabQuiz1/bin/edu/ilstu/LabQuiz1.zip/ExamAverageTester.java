/* 
 *File name: ExamAverageTester.java
 *
 *Programmer: Zachary Schleder
 *ULID: zschled
 *
 *Date: Sep 24, 2014
 *
 *Class: IT 168
 *Lecture session: SEC-10
 *Lecture Instructor: Matsuda
 *Lab Section: SEC-12
 *Lab Instructor: Nasiba Al-Rawi
 */
package edu.ilstu;

/**
 *<insert clas description here>
 *
 * @author Zachary Schleder
 *
 */
public class ExamAverageTester
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		double examone=80;
		double examtwo=90;
		double examthree=100;
		
		ExamAverageCalculator midTerm = new ExamAverageCalculator();
		
		midTerm.ExamAverageCalculator(examone,examtwo,examthree);
		
		System.out.println(midTerm.calculateExamAverage());
		
	}

}
