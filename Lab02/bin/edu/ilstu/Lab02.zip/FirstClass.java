/* 
 *File name: FirstClass.java
 *
 *Programmer: Zachary Schleder
 *ULID: zschled
 *
 *Date: Aug 27, 2014
 *
 *Class: IT 168
 *Lecture session: SEC-10
 *Lecture Instructor: Matsuda
 *Lab Section: SEC-12
 *Lab Instructor: Nasiba Al-Rawi
 */
package edu.ilstu;

/**
 *
 *
 * @author Zachary Schleder
 *
 */
public class FirstClass
{

	/**
	 * @param- A first program rearranging statements
	 */
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		System.out.println("Welcome to Java programming!");
		System.out.println("Java Rules!");
		System.out.print("My name is Zach Schleder.\n");
		System.out.print("Success!\n");
		System.out.print("\nGoodbye!");
	}

}
