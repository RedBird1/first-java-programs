/* 
 *File name: DistanceCalculator.java
 *
 *Programmer: Zachary Schleder
 *ULID: zschled
 *
 *Date: Aug 27, 2014
 *
 *Class: IT 168
 *Lecture session: SEC-10
 *Lecture Instructor: Matsuda
 *Lab Section: SEC-12
 *Lab Instructor: Nasiba Al-Rawi
 */
package edu.ilstu;

/**
 * it-168 Intoduction to Java
 *
 * @author Zachary Schleder
 * 
 *Distance Calculator: Rate x Time = Distance
 */
public class DistanceCalculator
{

	public static void main(String[] args)
	{
		int speed=20;
		int time=10;
		
		int distance=speed*time;
		
		System.out.print(distance);		

	}

}
